---
name: 股权激励管理
name_en: Equity Compensation
type: Composite Application
industry: General
apis: [SEC EDGAR, Alpha Vantage]
emoji: 📈
---

# 📈 股权激励管理

## Use Case
公司股权激励(ESOP/RSU)的授予+归属+行权+税务。

## Sample Output
```
【某上市公司 股权激励】
激励对象: 2,800人 (占员工34%)
池子: 占已发行 8% 流通股
本季度:
  - 新授予RSU 82万股
  - 归属 120万股 (市值¥0.4亿)
  - 行权 180人
税务:
  - 代扣代缴 ¥4,800万
  - 个人筹划咨询
```
