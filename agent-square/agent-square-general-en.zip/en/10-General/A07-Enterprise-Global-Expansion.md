---
name: 企业出海全案
name_en: Enterprise Global Expansion
type: Composite Application
industry: General
composed_of: [跨境电商合规, 多语言翻译官, 品牌出海顾问, 政策研究员]
source_refs: [Cultural Intelligence Strategist, French Consulting Market Navigator, Korean Business Navigator, China Market Localization Strategist]
apis: [RestCountries, NewsAPI, ExchangeRate-API, LibreTranslate]
emoji: 🌎
---

# 🌎 企业出海全案 Enterprise Global Expansion

## Use Case
中国企业出海东南亚/欧洲/北美/中东的市场准入+本地化+法务+招聘全流程。

## Agent Composition
```
[Cultural Intelligence Strategist] ← specialized
[French Consulting Market Navigator] ← specialized
[Korean Business Navigator] ← specialized
[政策研究员] ← Government Digital Presales
[多语言翻译官] ← Language Translator
```

## Bound APIs
| API | Purpose |
|-----|------|
| RestCountries | 国家基本信息 |
| NewsAPI | 当地新闻 |
| ExchangeRate-API | 多币种 |
| LibreTranslate | 翻译 |

## 核心工作流
1. **市场选择**：规模+增速+壁垒
2. **合规准入**：公司注册+牌照
3. **本地化**：产品+定价+传播
4. **人才招募**：本地团队
5. **运营迭代**：KPI+优化

## Sample Output
```
【某SaaS出海印度方案】
目标: 印度企业软件市场
市场选择理由:
  - 人口14亿 + GDP 7%增速
  - 英语商务环境友好
  - IT人才储备
准入:
  - GST注册 + 公司注册 (班加罗尔) 6-8周
  - FEMA 跨境投资规则备案
  - 数据本地化合规
本地化:
  - 产品: 支持UPI付款 + 多语(印地/泰米尔)
  - 定价: 本地PPP调整 -40%
  - 传播: LinkedIn为主 + 活动
招聘计划:
  - 班加罗尔 总经理+10人团队
  - 起薪 ₹25万卢比(CEO) / ₹8万(工程师)
法务:
  - 雇佣合约符合 Indian Labour Code
  - 劳资税+社保按当地
预算: 首年 $800K | M12目标 $1M ARR
```
