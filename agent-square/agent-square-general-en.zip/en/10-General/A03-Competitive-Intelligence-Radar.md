---
name: 竞争情报雷达
name_en: Competitive Intelligence Radar
type: Composite Application
industry: General
composed_of: [新闻聚合编辑, 舆情监控员, 消费者洞察专家, 股票分析师]
source_refs: [Trend Researcher, Content Creator, Analytics Reporter]
apis: [NewsAPI, GNews, Reddit, SEC EDGAR]
emoji: 🎯
---

# 🎯 竞争情报雷达 Competitive Intelligence Radar

## Use Case
战略部/CEO办公室用: 实时追踪竞争对手动向+产品+营销+人事+财务。

## Agent Composition
```
[新闻聚合编辑] ← Content Creator
[舆情监控员] ← Reddit Community Builder
[消费者洞察专家] ← Trend Researcher
[股票分析师] ← Financial Analyst
```

## Bound APIs
| API | Purpose |
|-----|------|
| NewsAPI + GNews | 新闻 |
| Reddit + HackerNews | 社群 |
| SEC EDGAR | 财务披露 |
| LinkedIn APIs(若可用) | 人事变动 |

## 核心工作流
1. **对手清单**：直接+潜在
2. **多维监控**：新闻/社交/财报/职场
3. **事件提取**：产品/定价/人事
4. **影响评估**：威胁等级
5. **应对建议**：防御/跟进/差异化

## Sample Output
```
【竞争雷达周报 W16】
监控对手: 8家 直接 + 12家 潜在
本周关键动向:
  🔴 竞品A: 发布新产品 X1 降价20%
     - 影响评估: 高 (直接冲击我们旗舰型号)
     - 建议: 评估跟进降价 or 加强价值沟通
  🟠 竞品B: CTO离职加盟某AI公司
     - 影响: 中 (技术路线可能调整)
     - 建议: 观察产品节奏
  🟠 竞品C: 融资$80M Series C (a16z领投)
     - 影响: 中 (营销军火升级)
     - 建议: 加固用户忠诚度
  🟡 竞品D: 某客户流失至对方
     - 已安排客户成功跟进
社区声量:
  - 我方 mention: 12K (↑5%)
  - 竞品A mention: 18K (↑22%) 因新品
  - 竞品B mention: 8K (↓8%)
产品对比矩阵: 见附件
```
