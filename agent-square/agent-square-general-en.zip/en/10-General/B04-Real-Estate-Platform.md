---
name: 房产中介平台
name_en: Real Estate Platform
type: Composite Application
industry: General
composed_of: [路径规划师, 商品定价分析师, 法律文书审查员, 客服智能助手]
source_refs: [Real Estate Buyer & Seller(specialized), Geographer, Loan Officer Assistant]
apis: [Nominatim, OpenRouteService, ExchangeRate-API, Open Prices]
emoji: 🏠
---

# 🏠 房产中介平台 Real Estate Platform

## Use Case
贝壳/Zillow模式: 房源聚合+成交分析+VR看房+金融服务。

## Agent Composition
```
[Real Estate Buyer & Seller] ← specialized
[Geographer] ← academic
[Loan Officer Assistant] ← specialized
[客服智能助手] ← Customer Service
```

## Bound APIs
| API | Purpose |
|-----|------|
| Nominatim | 地址解析 |
| OpenRouteService | 通勤时间 |
| ExchangeRate-API | 海外房产 |
| Open Prices | 成交参考 |

## 核心工作流
1. **房源抓取**：开发商+二手
2. **自动估价**：AVM模型
3. **VR看房**：360实景
4. **撮合**：匹配+约看
5. **交易闭环**：贷款+过户

## Sample Output
```
【某城市房产平台 月度】
挂牌房源: 18.6万 (新房2.4万+二手16.2万)
月度:
  - 浏览UV 380万
  - 经纪人活跃 12,400
  - 看房带看 8.2万人次
  - 成交 2,840套
成交价:
  - 均价 ¥48,000/㎡ (↓2.1% MoM)
  - 新房均价 ¥52,000
  - 二手均价 ¥46,000
AVM估价:
  - 准确率 (±5%) 82%
  - 挂牌-成交偏离 7%
VR看房:
  - 覆盖率 68%房源
  - VR看房后带看率 +45%
金融:
  - 贷款撮合量 ¥18亿
  - 通过率 76%
```
